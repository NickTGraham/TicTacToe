# CSC 242 Project 1 #
Author: Nick Graham

Compile:
make game

Run 3x3 Game:
./TicTacToe 3
    while in game enter the piece you want to play as and the number of the
    space when prompted

Run 9 Board:
./TicTacToe 9
    while in game enter the piece you want to play as and the move in the format
    board spot when prompted.
